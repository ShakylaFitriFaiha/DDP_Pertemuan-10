import main 

print('## Modul Luas Bangun Datar ##')

main.l_persegi(10)
main.l_persegipanjang(20,5)
main.l_segitiga(8,6)
main.l_lingkaran(16)
main.l_jajargenjang(15,8)