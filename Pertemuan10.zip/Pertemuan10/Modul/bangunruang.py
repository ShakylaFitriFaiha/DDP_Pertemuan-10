import main 

print('## Modul Luas Bangun Ruang ##')

main.l_balok(10,8,7)
main.l_kubus(16)
main.l_tabung(9,7)
main.l_limassegiempat(5,9)
main.l_prismasegitiga(18,10)