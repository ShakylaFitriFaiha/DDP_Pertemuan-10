import hitung

print('##Latihan Modul Hitung##')

hitung.tambah(6,8)
hitung.kurang(15,6)
hitung.kali(7,8)
hitung.bagi(9,3)
hitung.pangkat(18,2)